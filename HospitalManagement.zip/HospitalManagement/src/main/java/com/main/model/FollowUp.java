package com.main.model;

public enum FollowUp {
	YES, NO;
}
